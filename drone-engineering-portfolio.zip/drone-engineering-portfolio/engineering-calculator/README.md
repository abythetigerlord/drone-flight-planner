# Engineering Calculator

A command-line calculator for common introductory engineering equations.

## Run

```bash
python engineering_calculator.py
```

The calculator includes force (`F = m × a`), torque (`T = F × r`), electrical power (`P = V × I`), and Ohm's law (`V = I × R`).

