"""Common introductory engineering calculations."""


def force(mass_kg, acceleration_mps2):
    return mass_kg * acceleration_mps2


def torque(force_n, lever_arm_m):
    return force_n * lever_arm_m


def electrical_power(voltage_v, current_a):
    return voltage_v * current_a


def ohms_law(current_a, resistance_ohm):
    return current_a * resistance_ohm


def main():
    print("Engineering Calculator")
    print("1. Force  2. Torque  3. Electrical power  4. Ohm's law")
    choice = input("Choose a calculation: ").strip()
    if choice == "1":
        print(f"Force = {force(float(input('Mass (kg): ')), float(input('Acceleration (m/s²): '))):.2f} N")
    elif choice == "2":
        print(f"Torque = {torque(float(input('Force (N): ')), float(input('Lever arm (m): '))):.2f} N·m")
    elif choice == "3":
        print(f"Power = {electrical_power(float(input('Voltage (V): ')), float(input('Current (A): '))):.2f} W")
    elif choice == "4":
        print(f"Voltage = {ohms_law(float(input('Current (A): ')), float(input('Resistance (Ω): '))):.2f} V")
    else:
        print("Please choose 1, 2, 3, or 4.")


if __name__ == "__main__":
    main()

