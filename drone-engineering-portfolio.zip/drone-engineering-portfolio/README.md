# Drone & Engineering Python Portfolio

Three beginner-friendly projects for learning Python and building a GitHub portfolio:

1. `drone-flight-planner` — estimates range, flight time, battery use, and reserve.
2. `drone-telemetry-dashboard` — summarizes drone telemetry from a CSV file.
3. `engineering-calculator` — calculates common force, torque, power, and voltage values.

Each folder is designed to become its own GitHub repository.

## Run a project

```bash
cd drone-flight-planner
python flight_planner.py
```

The other projects use the same pattern: enter their folder, then run the Python file.

